# CliUniversalDemo

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.0.0.

## Start the server

Run `npm run start` to start the server. Navigate to `http://localhost:4000/`.
